$(document).ready(function(){
  $("#hidden").hide();
  $("#title").click(function(){
    $("#hidden").fadeToggle(3000, function(){
      $("#hidden").fadeToggle(1000);
    });
  });
});
