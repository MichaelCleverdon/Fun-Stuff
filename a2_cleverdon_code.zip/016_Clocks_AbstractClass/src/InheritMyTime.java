
public class InheritMyTime extends MyTime {

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

}
