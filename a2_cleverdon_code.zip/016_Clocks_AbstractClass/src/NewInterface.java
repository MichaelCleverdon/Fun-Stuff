
public interface NewInterface {
	
	public abstract void first();
	
	public abstract String second(int x);

}
