package arraylist;

import javax.swing.JOptionPane;



public class MainInside {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		gradingRequirements();
		StudentFirstNames a2 = new StudentFirstNames();
		boolean playAgain = true;
	Object[] choices = {"Add Name","Show Name", "Remove Name", "Replace Name", "Exit"};
	Object[] YesOrNo = {"Yes","No"};
	
	//Start While
	
		while (playAgain) {
		
			String choice = (String)JOptionPane.showInputDialog(null, "What can I do for you?", null, JOptionPane.PLAIN_MESSAGE, null, choices, choices[0]);
			
			//Start Add
			
			if(choice.equals("Add Name")){	
				a2.addStudents();
				int answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
				 if(answer == 1){
					 playAgain = false;
					 JOptionPane.showMessageDialog(null, "Thank you for playing");
				 }
				
		}
			//Start Show
			
			if(choice.equals("Show Name")){
				a2.showContents();
				
				int answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
				 if(answer == 1){
					 playAgain = false;
					 JOptionPane.showMessageDialog(null, "Thank you for playing");
				 }
				 
			}
			if(choice.equals("Remove Name")) {
				a2.removeStudents();
				int answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
				 if(answer == 1){
					 playAgain = false;
					 JOptionPane.showMessageDialog(null, "Thank you for playing");
				 }
			}	
			if(choice.equals("Replace Name")) {
				a2.replaceStudents();
				int answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
				 if(answer == 1){
					 playAgain = false;
					 JOptionPane.showMessageDialog(null, "Thank you for playing");
				 }
			}
			if(choice.equals("Exit")) {
				playAgain = false;
				System.exit(0);
			}
	}
	}
	private static void gradingRequirements() {
		// TODO Auto-generated method stub
		System.out.println(""
				+ "1. All JOP and jar'd\n"
				+ "2. First is a menu asking for desired options -- looped\n"
				+ "3. Menu: Show Names, Add Name, Remove Name, Replace Name, exit"
				+ "");
	}
		}

/*
1. add this functionality -- Ask for a name, add that name to ArrayList
1a. text -- ater each name, show size and contents
*/