package arraylist;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class StudentFirstNames {
	ArrayList <String> a2Students = new ArrayList<String>();
	String name = "";
	Scanner kbd = new Scanner(System.in);
	public ArrayList<String> getA2Students() {
		return a2Students;
	}

	public void setA2Students(ArrayList<String> a2Students) {
		this.a2Students = a2Students;
	}

	public StudentFirstNames() {
		// TODO Auto-generated method stub
		a2Students.add("Jeffrey");
		a2Students.add("Hunter");
		a2Students.add("Alyse");
		a2Students.add("Jackson");
		
	}


	public void showSize() {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Number of students names is: "+ a2Students.size());
	}

	public void showContents() {
		JOptionPane.showMessageDialog(null, "Current array list is \n" + a2Students); 
				

				
				
		
	}
	public void checkStudent(String name){
		JOptionPane.showMessageDialog(null, "Checking if the student is already in the system");
		JOptionPane.showMessageDialog(null, checkArrayList(name));
		
		
	}
	public String checkArrayList(String name) {
		// TODO Auto-generated method stub
		for(int i = 0; i < a2Students.size();i++) {
		if(name.equals(a2Students.get(i))){
			JOptionPane.showMessageDialog(null, "Checking for " + a2Students.get(i));
			a2Students.remove(a2Students.size()-1);
return("The student is already here, please use a different name");
		}
	}
		return("The student isn't already here");
	}
public void addStudents() {
		
		name = JOptionPane.showInputDialog(null, "What is your name?");
		JOptionPane.showMessageDialog(null, checkArrayList(name) + ", they have been added");
		a2Students.add(name);
		showContents();
}
public void removeStudents() {
	name = JOptionPane.showInputDialog(null, "Which student would you like to remove?");

	a2Students.remove(a2Students.indexOf(name));
	showContents();
}
public void replaceStudents() {
	showContents();
	name = JOptionPane.showInputDialog(null, "Which name do you want to replace");

	int index = a2Students.indexOf(name); 
	name = JOptionPane.showInputDialog(null, "What do you want to replace that name with?");

	a2Students.set(index, name);
	showContents();
	
}
}
