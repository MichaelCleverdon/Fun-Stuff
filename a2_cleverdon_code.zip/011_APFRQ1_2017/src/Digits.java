import java.util.ArrayList;
import java.util.Collections;

public class Digits {
	private ArrayList<Integer> digitList;
	
	public Digits(int num) {
		System.out.println(num);
	 digitList = new ArrayList<Integer>();
		int x=10;
		while(num>0) {
		int answer = num%x;
		digitList.add(0,answer);
		num = num/10;
		}
		//Collections.reverse(digitList);
		System.out.println(digitList);
		
		
	}
	public boolean isStrictlyIncreasing() {
		
		if(digitList.size()==1) {
		
			return true;
			}
		for(int i = 1; i<digitList.size(); i++) {
			if(digitList.get(i)>digitList.get(i-1)) {
				
			}
			else return false;
		}
		return true;
		
	}
}
