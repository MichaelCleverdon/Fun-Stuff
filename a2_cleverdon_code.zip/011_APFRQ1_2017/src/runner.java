
public class runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Digits mydigits = new Digits(1248);
			System.out.println(mydigits.isStrictlyIncreasing());
	}

}
