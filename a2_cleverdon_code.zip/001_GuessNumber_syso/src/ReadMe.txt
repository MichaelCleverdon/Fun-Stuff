Notes from "Start Here":

	//guess01 is called an "instance" of this class (vocab)
	// a class instance is also sometimes called an object of that class
	
	/*
		 * 1) Start with exact class name
		 * 2) Give that "instance" of that class a unique name
		 * 3) First time, so say "new"
		 * 4) Give the constructor name, but later we will put parameters
		 * (like player names, difficulty level, etc)
		 */
		
		// DRY---Don't Repeat Yourself

		
Notes from "Create Message":
	
	//Make a constructor -- a constructor initializes a class
	// it initializes the setup for this class
	
	
	
	/* 
	 * Started with "Greetings" -- But why limit ourselves?
	 * We could send any type of message, not just greetings
	 * So we want to make our classes "Abstract" (key vocab word)
	 * Why make many many classes when you can have one class for a group of things
	 * Make the class general 
	 */
	 
	 // Scope 	return type		name(lower case)	pass parameters
	 
	 //To make a contructor:
	// 1) public -- so other classes can access it
	// 2) exact same name as class
	// 3) () if you want to pass any info in
	// 4) {} code goes in there <<<-----
	
Notes from "Guess Number":
		
	//"Field" variables -- put ALL your variables in top section
	//Makes it super easy to change stuff
	//As you keep figuring out the best way to make your code work
	
	//Next, constructor(s) -- you can have multiple constructors
	//That would be called a constructor "stack"
	
	//Finally after variables and constructors
	//We place our "methods" -- these are the workers that do specific tasks for the program
	
	
	/*
	 * 4 types of loops:
	 * 1 for loop, if you know how many times you wanna loop
	 * 2 while, if you don't know how many times you wanna loop
	 * 3. do-while, variation of while
	 * 4. enhanced for loop for arrays	 
	 */
	 
	 
	 Inclusive first number, exclusive second number
	 This prevents duplication problems
	 