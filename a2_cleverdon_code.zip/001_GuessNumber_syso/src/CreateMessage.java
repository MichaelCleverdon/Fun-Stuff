
public class CreateMessage {

	
	
	
	
	
	
	public CreateMessage() {
	
		
		//Placeholder
	}
	
	
	
	public void msg(String message) {
		System.out.println(message);
	}
}
