import java.util.Random;
import java.util.Scanner;

/*
 * vocab: "Encapsulation" means keep all -related- code in 1 single class
 * don't spread things all over the place
 * 
 * Old days: "Spaghetti" code, couldn't trace everything
 * 
 * Now: Go to one class, find all -related- code in that class
 */



public class GuessNumber {
	private int lowerLimit = 0;
	private int upperLimit = 10;

	

	Random rand = new Random();
	
	Scanner keyboard = new Scanner(System.in);
	


	
	/*
	 * 1) Set lower and upper bounds on the numbers, like 0-100
	 * 2) Pick a random number in that range
	 * 3) Start looping --
	 * -- Guess
	 * -- Check for win
	 * -- if win Hooray!
	 * -- if no win repeat
	 * -- Set guess limit, like 5 tries
	 */
	
	
	
	
	public GuessNumber() {

		
		
	}
	
public void startGame() {
	 int guess;
	 int countLimit = 5;
	  Boolean gameOver = false;
	  Boolean gameRunning = true;
	//Field		Very Important is "Scope"
	//"Public" Means any other class can use; usually BAD!
	//"Private" Only used inside of this class; very good!
	//"Protected" means can be used by any other class in this package 
	//Protected is DEFAULT!!
	int answer = rand.nextInt(upperLimit)+lowerLimit;
	
	
	
	

	
	//Check for win
	// == is a test operator, always used in if's
	while (gameRunning && countLimit > 0) {
		countLimit --;
		System.out.println(countLimit);
		System.out.println("\nPlease enter your guess, between " + lowerLimit + " and " +(upperLimit - 1));
		System.out.println(answer);
		guess = keyboard.nextInt();
	if (guess == answer) {
		System.out.println("You won!!");
		gameRunning = false;
	}
	else if (guess > answer) {
			System.out.println("Sorry bro, you're too high");
		}
		else if (guess < answer) {
			System.out.println("Sorry bro, you're too low");
			
		}
		else {
			System.out.println("You broke the game!");
		}
	
	System.out.println("Your guess is " + guess);
	
	}	//end of While
	if (countLimit == 0 && gameRunning == true) {
		System.out.println("Sorry, you didn't guess the number in time");
	}
	else if (countLimit == 4 || countLimit == 3 && gameRunning == false) {
		System.out.println("Woah! You guesed it really quickly");
	}
	
	else if (countLimit == 2 || countLimit == 1 && gameRunning == false) {
		System.out.println("You guessed that in an average amount of time");
	}
	else if (countLimit == 1 || countLimit == 0 && gameRunning == false) {
		System.out.println("That was close, whew, but you made it!");
	}
	
	} // End of Method
	
	
	
	
} //End of Class
