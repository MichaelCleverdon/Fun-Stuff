import javax.swing.JFrame;

public class GiveMeAGUI {

	public void createAndShowGUI() {
		// TODO Auto-generated method stub
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame(" ScoreBoard ");
		
		//Create and set up the content pane
		ScoreBoard demo = new ScoreBoard();
		frame.setContentPane(demo.createContentPane());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 300);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
