import javax.swing.SwingUtilities;

public class StartMeUp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GiveMeAGUI myGui = new GiveMeAGUI();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				myGui.createAndShowGUI();
			}
		});
	}

}
