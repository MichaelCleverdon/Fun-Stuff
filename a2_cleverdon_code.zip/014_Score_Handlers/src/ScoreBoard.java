import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ScoreBoard implements ActionListener{
	//Example ...Scoreboard extends JFrame implements ActionListener GOOD
	//Example ..Scoreboard extends JFrame implements ActionListener, AnotherInterface GOOD
	//Example ..Scoreboard extends JFrame,JPanel implements ActionListener BAD (multiple inherits)
	
	//Extends means inherit = use all vars and methods of the superclass
	//Implements means you must use an "interface"
	
	int homeScoreAmount = 0;
	int visitorScoreAmount = 0;
	
	JPanel titlePanel, scorePanel, buttonPanel;
	JLabel homeLabel, visitorLabel, homeScore, visitorScore;
	JButton homeButton, resetButton;
	JButton switchButton;
	JButton add1H, add2H, add3H, add6H, minus1H, minus2H, minus3H, minus6H;
	JButton add1V, add2V, add3V, add6V, minus1V, minus2V, minus3V, minus6V;
	
	
	public Container createContentPane() {
		// TODO Auto-generated method stub
		JPanel totalGUI = new JPanel();
		totalGUI.setSize(400,300);
		totalGUI.setLayout(null);
		totalGUI.setBackground(Color.GRAY);
		titlePanel = new JPanel();
		titlePanel.setLayout(null);
		titlePanel.setLocation(40,50);
		titlePanel.setSize(300,30);
		titlePanel.setBackground(Color.BLACK);
		totalGUI.add(titlePanel);
		
		switchButton = new JButton("Switch");
		switchButton.setLocation(95,10);
		switchButton.setSize(200,30);
		switchButton.setHorizontalAlignment(0);
		totalGUI.add(switchButton);
		
		homeLabel = new JLabel("Home");
		homeLabel.setLocation(-47,0);
		homeLabel.setSize(200,30);
		homeLabel.setHorizontalAlignment(0);
		homeLabel.setForeground(Color.MAGENTA);
		titlePanel.add(homeLabel);
		
		
		visitorLabel = new JLabel("Visitor");
		visitorLabel.setLocation(150,0);
		visitorLabel.setSize(200,30);
		visitorLabel.setHorizontalAlignment(0);
		visitorLabel.setForeground(Color.PINK);
		titlePanel.add(visitorLabel);
		
		
		scorePanel = new JPanel();
		scorePanel.setLayout(null);
		scorePanel.setLocation(40,90);
		scorePanel.setSize(300,30);
		scorePanel.setBackground(Color.WHITE );
		totalGUI.add(scorePanel);
		
		homeScore = new JLabel(""+homeScoreAmount);
		homeScore.setHorizontalAlignment(0);
		homeScore.setSize(100,30);
		homeScore.setLocation(0,0);
		scorePanel.add(homeScore);
		
		visitorScore = new JLabel(""+visitorScoreAmount);
		visitorScore.setHorizontalAlignment(0);
		visitorScore.setSize(100,30);
		visitorScore.setLocation(200,0);
		scorePanel.add(visitorScore);
		
		buttonPanel = new JPanel();
		buttonPanel.setLayout(null);
		buttonPanel.setLocation(9,140);
		buttonPanel.setSize(375,100);
		totalGUI.add(buttonPanel);
		
		add1H = new JButton("+1");
		add1H.setLocation(0,0);
		add1H.setSize(60,30);
		add1H.addActionListener(this);
		buttonPanel.add(add1H);
		
		add2H = new JButton("+2");
		add2H.setLocation(60,0);
		add2H.setSize(60,30);
		add2H.addActionListener(this);
		buttonPanel.add(add2H);
		
		add3H = new JButton("+3");
		add3H.setLocation(120,0);
		add3H.setSize(60,30);
		add3H.addActionListener(this);
		buttonPanel.add(add3H);
		
		add6H = new JButton("+6");
		add6H.setLocation(0,30);
		add6H.setSize(60,30);
		add6H.addActionListener(this);
		buttonPanel.add(add6H);
		
		minus1H = new JButton("-1");
		minus1H.setLocation(60,30);
		minus1H.setSize(60,30);
		minus1H.addActionListener(this);
		buttonPanel.add(minus1H);
		
		add1V = new JButton("+1");
		add1V.setLocation(195,0);
		add1V.setSize(60,30);
		add1V.addActionListener(this);
		buttonPanel.add(add1V);
		
		add2V = new JButton("+2");
		add2V.setLocation(255,0);
		add2V.setSize(60,30);
		add2V.addActionListener(this);
		buttonPanel.add(add2V);
		
		add3V = new JButton("+3");
		add3V.setLocation(315,0);
		add3V.setSize(60,30);
		add3V.addActionListener(this);
		buttonPanel.add(add3V);
		
		add6V = new JButton("+6");
		add6V.setLocation(195,30);
		add6V.setSize(60,30);
		add6V.addActionListener(this);
		buttonPanel.add(add6V);
		
		minus1V = new JButton("-1");
		minus1V.setLocation(255,30);
		minus1V.setSize(60,30);
		minus1V.addActionListener(this);
		buttonPanel.add(minus1V);
		
		
		
		resetButton = new JButton("Reset Game");
		resetButton.setLocation(0,70);
		resetButton.setSize(375,30);
		resetButton.addActionListener(this);
		buttonPanel.add(resetButton);
		
		
		return totalGUI;
	}
	
	
	//This method came to us from the interface ActionListener
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == add1H) {
			homeScoreAmount += 1;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == add2H) {
			homeScoreAmount += 2;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == add3H) {
			homeScoreAmount += 3;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == add6H) {
			homeScoreAmount += 6;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == minus1H) {
			homeScoreAmount += 1;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == minus2H) {
			homeScoreAmount -= 2;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == minus3H) {
			homeScoreAmount -= 3;
			homeScore.setText(""+homeScoreAmount);
		}
		else if (e.getSource() == minus6H) {
			homeScoreAmount -= 6;
			homeScore.setText(""+homeScoreAmount);
		}
		//Start of Visitor Buttons
		else if (e.getSource() == add1V) {
			visitorScoreAmount += 1;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == add2V) {
			visitorScoreAmount += 2;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == add3V) {
			visitorScoreAmount += 3;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == add6V) {
			visitorScoreAmount += 6;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == minus1V) {
			visitorScoreAmount -= 1;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == minus2V) {
			visitorScoreAmount -= 2;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == minus3V) {
			visitorScoreAmount -= 3;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if (e.getSource() == minus6V) {
			visitorScoreAmount -= 6;
			visitorScore.setText("" + visitorScoreAmount);
		}
		else if(e.getSource() == resetButton) {
			homeScoreAmount = 0;
			visitorScoreAmount = 0;
			homeScore.setText("" + homeScoreAmount);
			visitorScore.setText("" + visitorScoreAmount);
		}
		
		
	}

}
