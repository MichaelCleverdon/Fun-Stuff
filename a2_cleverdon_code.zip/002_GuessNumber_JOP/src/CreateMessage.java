import javax.swing.JOptionPane;

public class CreateMessage {

	
	
	
	
	
	
	public CreateMessage() {
	
		
		//Placeholder
	}
	
	
	
	public void msg(String message) {
		JOptionPane.showMessageDialog(null, message);
	}
}
