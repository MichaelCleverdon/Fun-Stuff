import javax.swing.JOptionPane;

public class runner {

	public static void main(String[] args) {

		String first_welcome = "Yo! You are in my program duuuude! Hi!";
		String second_welcome = "In this first program, we are going to play a guess my number game";
		String third_welcome = "Are you ready to play?";
		int n = 10;

		CreateMessage welcome = new CreateMessage();
		welcome.msg(first_welcome);
		welcome.msg(second_welcome);
		welcome.msg(third_welcome);

		GuessNumber myGuess = new GuessNumber();
		myGuess.startGame();

		GuessNumber guess01 = new GuessNumber();
		
	}

}
