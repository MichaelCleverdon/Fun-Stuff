package stopwatch;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Stopwatch extends JFrame {
	
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");

	
	long startTime;
	long stopTime;
	double elapsedTime;
	boolean timeStarted = false;
	
	JButton startButton = new JButton("Start");
	JLabel startLabel = new JLabel();
	JTextField startTextField = new JTextField();
	
	JButton stopButton = new JButton("Stop");
	JLabel stopLabel = new JLabel();
	JTextField stopTextField = new JTextField();
	
	JButton closeButton = new JButton("Close");
	
	JLabel elapsedLabel = new JLabel();
	JTextField elapsedTextField = new JTextField();
	
	public Stopwatch(String title) {

		setTitle(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//Create and Setup content pane
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints gridConstraints = new GridBagConstraints();
		
		//Create and Setup components
		startButton.setText("Start Timing");

		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		getContentPane().add(startButton, gridConstraints);
		
		startLabel.setText(" Start System Time ");
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 0;
		getContentPane().add(startLabel, gridConstraints);
		
		startTextField.setText("");
		startTextField.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 0;
		getContentPane().add(startTextField, gridConstraints);
		
		//Add Action Listener to detect and respond to clicks
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				startButtonActionPerformed(e);
			}
		});
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButtonActionPerformed(e);
			}	
		});
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeButtonActionPerformed(e);
			}	
		});
		stopButton.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 1;
		getContentPane().add(stopButton, gridConstraints);
		
		stopLabel.setText(" Stop System Time ");
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 1;
		getContentPane().add(stopLabel, gridConstraints);
		
		stopTextField.setText("");
		stopTextField.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 1;
		getContentPane().add(stopTextField, gridConstraints);
		
		
		closeButton.setText("Close ALL Watches");
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 3;
		getContentPane().add(closeButton, gridConstraints);
		
		elapsedLabel.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 2;
		getContentPane().add(elapsedLabel, gridConstraints);
		
		elapsedTextField.setText("");
		elapsedTextField.setColumns(20);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 2;
		getContentPane().add(elapsedTextField, gridConstraints);
		
		setLocationRelativeTo(null);
		pack();
		
		
		
		
		
		
		
		
	}//End of Constructor
	protected void closeButtonActionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.exit(0);
	}
	protected void stopButtonActionPerformed(ActionEvent e) {
		if(timeStarted = true) {
		stopTime = System.currentTimeMillis();
		Date stopDate = new Date();
		stopTextField.setText(stopDate.toString());
		elapsedTextField.setText(String.valueOf((stopTime-startTime)/1000.0));
		timeStarted = false;
		}
	}
	protected void startButtonActionPerformed(ActionEvent e) {
		startTime = System.currentTimeMillis();
		Date startDate = new Date();
		startTextField.setText(startDate.toString());
		//startTextField.setText(String.valueOf(startTime);
		stopTextField.setText("");
		elapsedTextField.setText("");
		timeStarted = true;
	}//End of Listener
}//End of Class
