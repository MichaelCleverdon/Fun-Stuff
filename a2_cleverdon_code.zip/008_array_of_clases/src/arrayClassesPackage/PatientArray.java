package arrayClassesPackage;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class PatientArray {

	Patient[] myPatients = new Patient[10];
	public void buildArray() {
		myPatients[0] = new Patient();
		myPatients[0].setBreed("Boxer");
		myPatients[0].setGender("Female");
		myPatients[0].setAge(10);
		myPatients[0].setSymptoms("Cut on foot");
		
		myPatients[1] = new Patient();
		myPatients[1].setBreed("Black Lab");
		myPatients[1].setGender("Male");
		myPatients[1].setAge(4);
		myPatients[1].setSymptoms("Halitosis");
		
		myPatients[2] = new Patient();
		myPatients[2].setBreed("Tucan");
		myPatients[2].setGender("Female");
		myPatients[2].setAge(2);
		myPatients[2].setSymptoms("Cut on eyelid");
		
		myPatients[3] = new Patient();
		myPatients[3].setBreed("Parrot");
		myPatients[3].setGender("Unknown");
		myPatients[3].setAge(1);
		myPatients[3].setSymptoms("Missing a foot");
		
		myPatients[4] = new Patient();
		myPatients[4].setBreed("Garden Snake");
		myPatients[4].setGender("Unknown");
		myPatients[4].setAge(7);
		myPatients[4].setSymptoms("Swallowed a lego");
		
		myPatients[5] = new Patient();
		myPatients[5].setBreed("Python");
		myPatients[5].setGender("Unknown");
		myPatients[5].setAge(1);
		myPatients[5].setSymptoms("Drank some cyanide");

		myPatients[6] = new Patient();
		myPatients[6].setBreed("Siamese Cat");
		myPatients[6].setGender("Female");
		myPatients[6].setAge(6);
		myPatients[6].setSymptoms("Cut on left side");
		
		myPatients[7] = new Patient();
		myPatients[7].setBreed("Howler Monkey");
		myPatients[7].setGender("Male");
		myPatients[7].setAge(5);
		myPatients[7].setSymptoms("Can't howl");
		
		myPatients[8] = new Patient();
		myPatients[8].setBreed("Spider Monkey");
		myPatients[8].setGender("Female");
		myPatients[8].setAge(1);
		myPatients[8].setSymptoms("Can't shoot webs and a broken arm");
		
	}
	public void showArray() {
		// TODO Auto-generated method stub
		for(int i=0; i<myPatients.length; i++) {
			System.out.println("Breed is: " + myPatients[i].getBreed());
			System.out.println("Gender is: " +  myPatients[i].getGender());
			System.out.println("Age is: " + myPatients[i].getAge());
			System.out.println("Symptoms are: " + myPatients[i].getSymptoms());
			System.out.println();
		}
	}
	public void inputArray() {
		myPatients[9] = new Patient();
		
		myPatients[9].setBreed(JOptionPane.showInputDialog("What is the Breed of your animal?"));
		myPatients[9].setGender(JOptionPane.showInputDialog("What is the Gender of your animal?"));
		myPatients[9].setAge(Integer.parseInt(JOptionPane.showInputDialog("What is the Age of your animal?")));
		myPatients[9].setSymptoms(JOptionPane.showInputDialog("What are the symptoms of your animal?"));
		
	}

}
