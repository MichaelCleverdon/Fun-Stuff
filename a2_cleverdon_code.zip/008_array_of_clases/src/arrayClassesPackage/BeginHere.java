package arrayClassesPackage;

public class BeginHere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Patient myStudent = new Patient();
		PatientArray myStudentArray = new PatientArray();
	
		myStudentArray.buildArray();
		myStudentArray.inputArray();
		myStudentArray.showArray();
	}

}
/*
 * 1. (learn arrays - for large data ALWAY use a database, JDBC - Java Data Base Connectivity to, (MySql))
 * 2. You work in a vet's office, and you want a check-in tag for the vet and, this is a procedure and billing record
 * 3. Record:
 * 01 - Species (dog, cat, horse, bird)
 * 02 - gender (m, f, o)
 * 03 - age
 * 04 - symptoms
 * 4.
 * 5.
 *  
 * 
 */
