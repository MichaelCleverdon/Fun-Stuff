import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class RunHere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createAndShowGui();
			}
			
		});
	}
	private static void createAndShowGui() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame(" There are 3 JPanels in here;");
		
		//Create and set up the content pane
		PanelExample_Extended demo = new PanelExample_Extended();
		frame.setContentPane(demo.createContentPane());
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(580, 300);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
