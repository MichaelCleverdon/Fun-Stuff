import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class PanelExample_Extended {

	public JPanel createContentPane() {
		//We create a bottom JPanel to place everything on.
		JPanel totalGUI = new JPanel();
		
		// We set the Layout Manager to null so we can manually place the Panels.
		totalGUI.setLayout(null);
		
		//Now we create a new panel, size it, shape it, and color it green
		// Then add it to the bottom JPanel
		GridBagConstraints gbc = new GridBagConstraints();
		
		totalGUI.setBackground((Color.yellow));
		JPanel redPanel = new JPanel();
		redPanel.setBackground(Color.red);
		redPanel.setLocation(10,35);
		redPanel.setSize(100,100);
		totalGUI.add(redPanel);
		
		
		JPanel blueRect = new JPanel();
		blueRect.setBackground(Color.blue);
		blueRect.setLocation(120,35);
		blueRect.setSize(330,100);
		totalGUI.add(blueRect);
		
		JPanel greenPanel = new JPanel();
		greenPanel.setBackground(Color.green);
		greenPanel.setLocation(460,35);
		greenPanel.setSize(100,100);
		totalGUI.add(greenPanel);
		
		JPanel pinkPanel = new JPanel();
		pinkPanel.setLayout(null);
		pinkPanel.setBackground(Color.pink);
		pinkPanel.setLocation(10,150);
		pinkPanel.setSize(550,100);
		totalGUI.add(pinkPanel);
		
		JPanel yellowPanel = new JPanel();
		yellowPanel.setLayout(null);
		yellowPanel.setBackground(Color.yellow);
		yellowPanel.setLocation(75,10);
		yellowPanel.setSize(400,80);
		//yellowPanel.setHorizontalAlignment(0.CENTER);
		pinkPanel.add(yellowPanel);
		
		JPanel cyanPanel = new JPanel();
		cyanPanel.setLayout(null);
		cyanPanel.setBackground(Color.cyan);
		cyanPanel.setLocation(100,10);
		cyanPanel.setSize(200,60);
		//yellowPanel.setHorizontalAlignment(0.CENTER);
		yellowPanel.add(cyanPanel);
		
		JButton pushMe = new JButton("Push Me!");
		pushMe.setLocation(30,15);
		pushMe.setSize(140,25);
		cyanPanel.add(pushMe);
		
		JLabel yellowLabel = new JLabel("Left");
		yellowLabel.setLocation(20,30);
		yellowLabel.setSize(50,40);
		yellowLabel.setHorizontalAlignment(SwingConstants.LEFT);
		pinkPanel.add(yellowLabel);
		
		JLabel yellowLabel2 = new JLabel("Right");
		yellowLabel2.setLocation(480,30);
		yellowLabel2.setSize(50,40);
		yellowLabel2.setHorizontalAlignment(SwingConstants.RIGHT);
		pinkPanel.add(yellowLabel2);
		
		//yellowPanel.add(yellowLabel);
		
		JLabel redLabel = new JLabel("Red");
		redLabel.setLocation(0,0);
		redLabel.setSize(50,40);
		redLabel.setHorizontalAlignment(0);
		redPanel.add(redLabel);
		
		JLabel blueLabel = new JLabel("Blue");
		blueLabel.setLocation(0,0);
		blueLabel.setSize(50,40);
		blueLabel.setHorizontalAlignment(0);
		blueRect.add(blueLabel);
		
		JLabel greenLabel = new JLabel("Green");
		greenLabel.setLocation(0,0);
		greenLabel.setSize(50,40);
		greenLabel.setHorizontalAlignment(0);
		greenPanel.add(greenLabel);
		
		
		//Make the JPanel visible
		gbc.gridx = 0;
		gbc.gridy = 1;
		totalGUI.setOpaque(true);
		JButton startButton = new JButton("Start");
		greenPanel.setLayout(null);
		startButton.setBounds(15,30,70,30);
		greenPanel.add(startButton,gbc);
		
		JButton stopButton = new JButton("Stop");
		redPanel.setLayout(null);
		stopButton.setBounds(15,30,70,30);
		redPanel.add(stopButton,gbc);

		
		
		

		
		return totalGUI;
	}
}
