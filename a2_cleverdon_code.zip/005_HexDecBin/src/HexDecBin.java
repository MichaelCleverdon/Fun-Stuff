import java.util.Scanner;

import javax.swing.JOptionPane;
public class HexDecBin {
	//Debugged Scanner naming problem
	
	
	
	
	
	
	
	//HexBinaryAdapter()
	
	
	
	
	
	
	private String hex = "";
	private int num;
	
	public HexDecBin() {
		JOptionPane.showMessageDialog(null, "Welcome to my Hexadecimal, Decimal or "
				+ "Binary conversion program!");
		
		String name = JOptionPane.showInputDialog(null, "What is your name?");
		if(name == null) {
	JOptionPane.showMessageDialog(null,"See ya next time");
	System.exit(0);	
	}
		
		
			JOptionPane.showMessageDialog(null, "Hello " + name + ", welcome to my program");
			
	}

	public void setHexNumber() {
		
		Object[] choices = {"Hex","Dec","Bin"};
		Object[] convertChoices = {"Hex","Dec","Bin"};
		Object[] YesOrNo = {"Yes", "No"};
		Object[] HexCodes = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		Boolean playAgain = true;
		String convertChoice;
		int answer;
		int bin;
		while(playAgain) {
		String choiceStart = (String)JOptionPane.showInputDialog(null, "Which do you want to start your conversion with?", null, JOptionPane.PLAIN_MESSAGE, null, choices, choices[0]);
		if(choiceStart == null) {
			JOptionPane.showMessageDialog(null,"See ya next time");
			System.exit(0);	
			}
		convertChoice = (String)JOptionPane.showInputDialog(null, "Which would you like to convert to?", null, JOptionPane.PLAIN_MESSAGE, null, convertChoices, convertChoices[0]);
		if(convertChoice == null) {
			JOptionPane.showMessageDialog(null,"See ya next time");
			System.exit(0);	
			}
		switch(choiceStart) {
		case "Hex":
			
		hex = JOptionPane.showInputDialog("\nEnter the hex number: ");
	
		// mouse over parseInt to read pop-up guide
		num = Integer.parseInt(hex, 16);
		JOptionPane.showMessageDialog(null,"You have entered hex " + hex);
		 
		switch(convertChoice) {
		case "Hex":
			JOptionPane.showMessageDialog(null, "What are you doing? You started in Hex");
		break;
		case "Dec":
			JOptionPane.showMessageDialog(null , "Decimal value is: " + num + " " + "(remember 0-" + num + " has " + (num+1) + " values)");
		break;
		case "Bin":
			String binary = Integer.toBinaryString(num);
			JOptionPane.showMessageDialog(null, "Binary value is: " + binary);
		break;
		
		
			 
		}
		answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
		 if(answer == 1){
			 playAgain = false;
			 JOptionPane.showMessageDialog(null, "Thank you for playing!");
		}
		break; // End of Hex
		
		case "Bin":

		switch(convertChoice){
		
		case "Hex":
		bin = Integer.parseInt(JOptionPane.showInputDialog("\nEnter the binary number: "),2);
			JOptionPane.showMessageDialog(null, "Binary: " + bin);
		hex = Integer.toHexString(bin);
		JOptionPane.showMessageDialog(null, "Your hexadecimal equivilent is: " + hex);
		break;
		
		case "Bin":
			JOptionPane.showMessageDialog(null, "Get out of here! You're already in binary");
		break;
		
		case "Dec":
		bin = Integer.parseInt(JOptionPane.showInputDialog("\nEnter the binary number: "),2);
			JOptionPane.showMessageDialog(null, "Your decimal equivilent is: " + bin);
		
		break;
		}
			answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
			 if(answer == 1){
				 playAgain = false;
				 JOptionPane.showMessageDialog(null, "Thank you for playing!");
		}
		
		break; //End of Bin
		case "Dec":
		
		int dec = Integer.parseInt(JOptionPane.showInputDialog("Please input a decimal number"));
		
		switch(convertChoice){
		case "Hex":
			String Hex = Integer.toHexString(dec);
			JOptionPane.showMessageDialog(null, "Your hexadecimal input for " + dec + " is " + Hex);
		break;
		case "Dec":
			JOptionPane.showMessageDialog(null, "What are you doing? You're already in Decimal");
		break;
		case "Bin":
			String binary = Integer.toBinaryString(dec);
			JOptionPane.showMessageDialog(null, "Your binary input for " + dec + " is " + binary);
		break;
		}
		answer = JOptionPane.showOptionDialog(null, "Do you want to play again?", null, JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null,YesOrNo , "Yes");
		 if(answer == 1){
			 playAgain = false;
			 JOptionPane.showMessageDialog(null, "Thank you for playing!");
	}
		break; //End of Dec
		}
		
		
		}
		}
		/*if(playAgain == false || choiceStart == null || convertChoice == null) {
		JOptionPane.showMessageDialog(null, "Thank you for playing");
		}*/
		
	}
/*	public void convert() {
		String binary = Integer.toBinaryString(num);
		
		JOptionPane.showMessageDialog(null, "Binary value is: " + binary);
		JOptionPane.showMessageDialog(null, "Number of bits is " + binary.length());
		JOptionPane.showMessageDialog(null, "Number of whole nibbles (4 bits) is "+ Math.round(binary.length()/4) + " with "+ Math.floorMod(binary.length(), 4) + " bits left over");
		JOptionPane.showMessageDialog(null, "Number of whole bytes (8 bits) is " + Math.round(binary.length()/8)+ " with "+ Math.floorMod(binary.length(), 8) +" left over");
	}*/
		





