
public class RunHere {

	
	/*
	 * 
	 * Grading Req's
	 * 
	 * 1. All JOP's
	 * 2. Runnable .jar
	 * 3. Ask for name, repeat name with friendly "Hello"
	 * 4. Ask "What base are we starting with, Hex, Dec, Bin
	 * 5. Ask "What base are we converting to
	 * 6. Enter a starting number
	 * 7. Do conversion, display result
	 * 8. Ask if they want to go again
	 * if yes: start over, if no: friendly exit
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Added hex to bin functionality
	/*	BinPower binpower = new BinPower();
		binpower.setBinary();*/
		
		
		HexDecBin baseConverter = new HexDecBin();
		
		
		
		baseConverter.setHexNumber();
		
		
	}

}
