package array_fun;

import javax.swing.JOptionPane;

public class ArrayFun {

	public void showInstructions() {
		
		
		String[] messages = new String[8];
		messages[0] = "Hi, hows it going";
		messages[1] = "1. Arrays have a FIXED length!!! At the time they are created";
		messages[2] = "2. Two ways to set array size:";
		messages[3] = "-- one way is to set size with a constructor [size]";
		messages[4] = " -- another way is to set the size from initial data";
		messages[5] = "Dynamic - when a program is running: ";
		messages[6] = "Can NOT NOT NO WAY NO HOW change SIZE of the array!";
		messages[7] = "But OF COURSE you can change the values";

		JOptionPane.showMessageDialog(null, messages);
		
	}
	public void intArrayExample() {
		
		String combination = "";
		String combination2 = "";
		
		int[] intText = new int[10]; // int[] intText - this is the math notation
		intText[0] = 9;
		intText[1] = 8;
		intText[2] = 7;
		intText[3] = 6;
		intText[4] = 5;
		intText[5] = 4;
		intText[6] = 3;
		intText[7] = 2;
		intText[8] = 1;
		intText[9] = 0;
		
		int[] int2Text = {0,1,2,3,4,5,6,7,8,9};
		//String[] stringText = new String[10];
		JOptionPane.showMessageDialog(null, "\n\n Starting test of arrays");
		JOptionPane.showMessageDialog(null, "Number 1: ");
		for(int i = 0;i<int2Text.length; i++) {
			
			combination += "\nint2Text[" + i + "]: " + int2Text[i];
			
		}
		JOptionPane.showMessageDialog(null, combination);
		
		JOptionPane.showMessageDialog(null, "\n\n Number 2: ");
		for(int i = 0;i<intText.length; i++) {
			
			combination2 += "\nint2Text[" + i + "]: " + intText[i];
			
		}

	JOptionPane.showMessageDialog(null, combination2);
	}
	
}
