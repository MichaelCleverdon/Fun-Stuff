package array_fun;

import javax.swing.JOptionPane;

public class Matrix {
//Matrix is another name for a multidimensional array
	//2d like a checker board, chess board etc
	//2d array is often called a matrix

	private int [][] ticTacToe = {
			{00,01,02},
			{10,11,12},
			{20,21,22}
	};
	private int [][] game = {
			{0,0,0},
			{0,1,0},
			{0,0,0}
	};
	private char [][]realGame = {
			{'-','-','-'},
			{'-','-','-'},
			{'-','-','-'}
	};
	String[][] checkers = new String[8][8];
	public Boolean win = false;
public void build2dArray(){
	
	checkers[0][0]="red";
	checkers[0][7]="red king";
	checkers[3][4]=" ";
	checkers[7][0]="black";
	checkers[7][7]="black king";
	JOptionPane.showMessageDialog(null, "...building a 2D array, meaning rows and columns");
	
	for(int r = 0; r < ticTacToe.length; r++) {
		for(int c = 0; c <ticTacToe[0].length; c++) {
		System.out.print("Value at ticTacToe["+r+"]["+c+"] is " +ticTacToe[r][c]);
		System.out.println();
		}
	}
	System.out.println();
	for(int r = 0; r < ticTacToe.length; r++) {
		System.out.println();
		for(int c = 0; c <ticTacToe[0].length; c++) {
		System.out.print(ticTacToe[r][c]+ " ");
		}
	}
	for(int r = 0; r < realGame.length; r++) {
		System.out.println();
		for(int c = 0; c <realGame[0].length; c++) {
		System.out.print(realGame[r][c]+ " ");
		}
	}	
}


public void gameBoard() {
	String currentPlayer = "";
	
	/*
	System.out.println("\nPrint initial game board, plater starts in the middle\n");
	for(int r = 0; r < game.length; r++) {
		System.out.println();
		for(int c = 0; c <game[0].length; c++) {
		System.out.print(game[r][c]+ " ");
		}
	}
	System.out.println("\nNow set row 0 col 0 to '1', print again\n");
	game[0][0] = 1;
	for(int r = 0; r < game.length; r++) {
		System.out.println();
		for(int c = 0; c <game[0].length; c++) {
		System.out.print(game[r][c]+ " ");
		}
	}
	System.out.println("\nNow set row 2 col 2 to '1', print again\n");
	game[2][2] = 1;
	for(int r = 0; r < game.length; r++) {
		System.out.println();
		for(int c = 0; c <game[0].length; c++) {
		System.out.print(game[r][c]+ " ");
		}
	}
	System.out.println("Now work with real game X and O");
	
	*/
	////////////////////////////
	/////Start of Real game/////
	////////////////////////////
	int Player = 0;
	int row;
	int column;
	do{
	if(Player == 0){
		System.out.println("Hey player X, please pick which row to put your X into");
		row = Integer.parseInt(JOptionPane.showInputDialog("Pick a row"));
		System.out.println("Hey player X, please pick which column to put your X into");
		column = Integer.parseInt(JOptionPane.showInputDialog("Pick a column"));
		if(checkFull(row, column) == false) { 
		realGame[row][column] = 'X';
		displayBoard();
		System.out.println("Your turn is now over");
		Player = 1;	
}else {
	System.out.println("You tried to cheat, you lose your turn");
}
	}
	if(checkWin()==true){
		if (Player == 0) currentPlayer = "Player O";
		if (Player == 1) currentPlayer = "Player X";
		JOptionPane.showMessageDialog(null, "Congratulations " + currentPlayer + ", You won Tic Tac Toe");
		System.exit(0);
	}
	if(Player == 1){
		System.out.println("Hey player O, please pick which row to put your O into");
		row = Integer.parseInt(JOptionPane.showInputDialog("Pick a row"));
		System.out.println("Hey player O, please pick which column to put your O into");
		column = Integer.parseInt(JOptionPane.showInputDialog("Pick a column"));
		if(checkFull(row, column)== false) {
		realGame[row][column] = 'O';
		displayBoard();
	
		System.out.println("Your turn is now over");
		
		
		
		}
		else {
			System.out.println("You tried to cheat, you lose your turn");
		}
		
		Player = 0;	
	}
	if(checkWin()==true){
		if (Player == 0) currentPlayer = "Player O";
		if (Player == 1) currentPlayer = "Player X";
		JOptionPane.showMessageDialog(null, "Congratulations " + currentPlayer + ", You won Tic Tac Toe");
		System.exit(0);
	}
	}while(checkWin()==false||checkTie()==false);
	//Win check
	
	if(checkWin()==true){
		if (Player == 1) currentPlayer = "Player O";
		if (Player == 0) currentPlayer = "Player X";
		JOptionPane.showMessageDialog(null, "Congratulations " + currentPlayer + ", You won Tic Tac Toe");
		System.exit(0);
	}
	if(checkTie()==true) {
		JOptionPane.showMessageDialog(null, "Sadly, no one won in the time limit, sorry!");
	}

	
}
public Boolean checkWin() {
	
	if(realGame[0][0]==realGame[1][1] && realGame[1][1]==realGame[2][2] && realGame[0][0] != '-') win = true;
	else if(realGame[2][0]==realGame[1][1] && realGame[1][1]==realGame[0][2] && realGame[2][0] != '-') win = true;//Done with Diagonals
	else if(realGame[0][0]==realGame[0][1] && realGame[0][1]==realGame[0][2] && realGame[0][0] != '-') win = true;
	else if(realGame[1][0]==realGame[1][1] && realGame[1][1]==realGame[1][2] && realGame[1][0] != '-') win = true;
	else if(realGame[2][0]==realGame[2][1] && realGame[2][1]==realGame[2][2] && realGame[2][0] != '-') win = true;//Done with rows
	else if(realGame[0][0]==realGame[1][0] && realGame[1][0]==realGame[2][0] && realGame[0][0] != '-') win = true;
	else if(realGame[0][1]==realGame[1][1] && realGame[1][1]==realGame[2][1] && realGame[0][1] != '-') win = true;
	else if(realGame[0][2]==realGame[1][2] && realGame[1][2]==realGame[2][2] && realGame[0][2] != '-') win = true;
	//Done with columns
	return win;
	
}
public Boolean checkTie() {
	if(realGame[0][0]+""!="-"&&realGame[0][1]+""!="-"&&realGame[0][2]+""!="-"&&
			realGame[1][0]+""!="-"&&realGame[1][1]+""!="-"&&realGame[1][2]+""!="-"&&
			realGame[2][0]+""!="-"&&realGame[2][1]+""!="-"&&realGame[2][2]+""!="-") {
		return true;
	}
	return false;
}
public Boolean checkFull(int row, int column) {
	if(realGame[row][column] == 'X' || realGame[row][column] == 'O') {
	return true;
	}
	else {
		return false;
	}
}
public void displayBoard() {
	for(int r = 0; r < realGame.length; r++) {
		System.out.println();
		for(int c = 0; c <realGame[0].length; c++) {
		System.out.print(realGame[r][c]+ " ");
		}
	}
}
}