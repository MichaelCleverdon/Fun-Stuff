package array_fun;

public class TheMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//	ArrayFun learnArrays = new ArrayFun();
		//	learnArrays.showInstructions();
		//	learnArrays.intArrayExample();
			Matrix my2d = new Matrix();
			my2d.gameBoard();
	}

}
