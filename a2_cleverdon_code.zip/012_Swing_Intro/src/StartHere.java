
public class StartHere {

public static void main(String[] args) {
			FirstWindow fw = new FirstWindow();
		//	fw.setVisible(true);
	}

}
