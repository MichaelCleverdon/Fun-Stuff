import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FirstWindow extends JFrame{

	
	public FirstWindow() {
		super("My computer is VERY special!");
		System.out.println("This is working");
		setSize(1200,800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		JPanel p1 = new JPanel(new GridBagLayout());
		p1.setBackground(Color.cyan);
		
		JPanel p2 = new JPanel();
		p2.setBackground(Color.red);
		
		JPanel p3 = new JPanel(new GridBagLayout(	));
		p3.setBackground(Color.ORANGE);
		
		JPanel p4 = new JPanel(new GridBagLayout());
		p4.setBackground(Color.yellow);
		
		JPanel p5 = new JPanel(new GridBagLayout());
		p5.setBackground(Color.black);
		
		
		JButton b1 = new JButton("Close");
		b1.setBackground(Color.white);
		JButton button = new JButton("Close");
		button.setBackground(Color.white);
		JButton b2 = new JButton("Open");
		b2.setBackground(Color.white);
		JButton b3 = new JButton("Abre");
		b3.setBackground(Color.white);
		JButton b4 = new JButton("Cierra");
		b4.setBackground(Color.white);
		JButton b5 = new JButton("Tall");
		b5.setBackground(Color.white);
		JButton b6 = new JButton("Short");
		b6.setBackground(Color.white);
		JButton b7 = new JButton("Alto");
		b7.setBackground(Color.white);
		JButton b8 = new JButton("Bajo");
		b8.setBackground(Color.white);
		JButton b9 = new JButton("Espanol");
		b9.setBackground(Color.white);
		
		
		b1.setBackground(Color.white);
		JCheckBox cb1 = new JCheckBox("Do you LOVE Minecraft?");
		cb1.setBackground(Color.LIGHT_GRAY);
		JCheckBox cb2 = new JCheckBox("Do you LOVE World of Warcraft?");
		Color myNewColor = new Color (100,150,10,200);
		JButton myLabel1 = new JButton("Fancy label1!");
		JButton myLabel2 = new JButton("Fancy label2!");
		JButton myLabel3 = new JButton("Fancy label3!");
		JLabel myLabel4 = new JLabel("Fancy label4!");
		JLabel myLabel5 = new JLabel("Fancy label5!");
		JLabel myLabel6 = new JLabel("Fancy label6!");
		
		JLabel myLabel7 = new JLabel("Fancy label7! ");
		JLabel myLabel8 = new JLabel("Fancy label8! ");
		JLabel myLabel9 = new JLabel("Fancy label9! ");
		
		
		
		JTextArea myTextArea = new JTextArea("Fancy TextArea");
		JTextField myTextField = new JTextField("Fancy TextField");
		cb2.setBackground(myNewColor);
		JRadioButton rb1 = new JRadioButton("Hiya");
		JRadioButton rb2 = new JRadioButton("Hello");
		JRadioButton rb3 = new JRadioButton("Howdy");
		JRadioButton rb4 = new JRadioButton("Hi");
		
		// East 3 wide x 1
		// Center 3x3
		// West 2widex3
		
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(15,15,15,15);
		
		add(p1, BorderLayout.SOUTH);
		add(p2, BorderLayout.NORTH);
		add(p3, BorderLayout.CENTER);
		add(p4, BorderLayout.WEST);
		add(p5, BorderLayout.EAST);
		p1.add(b1);
		p2.add(cb1);
		p2.add(cb2);
		
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		p3.add(button, gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		p3.add(b2, gbc);
		gbc.gridx = 2;
		gbc.gridy = 0;
		p3.add(b3, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 1;
		p3.add(b4, gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		p3.add(b5, gbc);
		gbc.gridx = 2;
		gbc.gridy = 1;
		p3.add(b6, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 2;
		p3.add(b7, gbc);
		gbc.gridx = 1;
		gbc.gridy = 2;
		p3.add(b8, gbc);
		gbc.gridx = 2;
		gbc.gridy = 2;
		p3.add(b9, gbc);
		
		gbc.gridx = 0;
		gbc.gridy = 0;
		p5.add(rb1,gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		p5.add(rb2, gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		p5.add(b1,gbc);
		
		
		gbc.gridx = 0;
		gbc.gridy = 0;	
		p4.add(myLabel1,gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		p4.add(myLabel2,gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		p4.add(myLabel3,gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		p4.add(myLabel4,gbc);
		
		p1.add(myLabel7);
		p1.add(myLabel8);
		p1.add(myLabel9);
		setVisible(true);
	}//End of constructor
	
	
	//public void setVisible(boolean b) {
	//System.out.println("HI");	
		
	//}//End of setVisible
	

}//End of FirstWindow
