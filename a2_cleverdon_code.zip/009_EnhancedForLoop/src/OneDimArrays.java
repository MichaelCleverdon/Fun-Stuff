
public class OneDimArrays {

	int[] myInts = {5,2,8,9,12,43};
	String myStrings[] = {"Hi","Howdy","Happy Christmas", "Merry Birthday"};
	
	float[] myFloat = new float[5];
	double[] myDouble = new double[5];
	
	private void init_myDouble() {
		myDouble[0] = 1.0;
		myDouble[1] = 1.130;
		myDouble[2] = 2.0;
		myDouble[3] = 1.01;
		myDouble[4] = 10.0;
	}
	private void init_myFloat() {
		myFloat[0] = (float)1.0;
		myFloat[1] = (float)5;
		myFloat[2] = (float)2.0;
		myFloat[3] = (float)1.01;
		myFloat[4] = (float)10.0;
	}
	public void sysoArray() {
	init_myDouble();
	init_myFloat();
		// TODO Auto-generated method stub
		
		
		for(int i : myInts) {
			System.out.print(i + " ");
			}
		//////////////////
		System.out.println();
		
		for(String i : myStrings) {
			System.out.println(i + " ");
		}
		System.out.println("Starting Doubles");
		for(double i : myDouble) {
			System.out.println(i + " ");
		}
		System.out.println("Starting floats");
		for(float f : myFloat) {
			System.out.println(f + " ");
		}
		
	}

}
