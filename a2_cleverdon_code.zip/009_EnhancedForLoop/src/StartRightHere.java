
public class StartRightHere {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OneDimArrays oneDim = new OneDimArrays();
		oneDim.sysoArray();
	}

}
