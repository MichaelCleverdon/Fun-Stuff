Julius Caesar (Roman General) is credited with our first "cipher"


This is a shift cipher, where each character is shifted by the same number a -> b  c -> d