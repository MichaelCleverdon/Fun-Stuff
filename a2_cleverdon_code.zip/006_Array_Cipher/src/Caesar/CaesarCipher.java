package Caesar;

public class CaesarCipher {

private static String alpha = "abcdefghijklmnopqrstuvwxyz0123456789.:'";
private static int alphaLength = alpha.length();
private static String spaceCheck = " ";

	public static String encode(String plainText, int key ) {
		String codedWord = "";
		
	
		// TODO Auto-generated method stub
		
		for (int i = 0; i < alpha.length(); i++) {
			//System.out.println(alpha.charAt(i));
		}
		System.out.println("\n\n");
		for (int i=0; i <= plainText.length()-1; i++) {
			spaceCheck = ""+plainText.charAt(i);
			if(spaceCheck.equals(" ")) {
				codedWord += spaceCheck;
			}
			else {
			int inx = alpha.indexOf(plainText.charAt(i));
			int shiftInx = (inx + key) % alpha.length();
			
			
			if (shiftInx >=alphaLength) {
				shiftInx = shiftInx - alphaLength;
			}
			codedWord += alpha.charAt(shiftInx);
			
		//	codedWord += plainText.charAt(i);
		}
		}
		
		return codedWord;
		
	}

	public static String decode(String plainText, int key) {
		// TODO Auto-generated method stub
		String decodedWord = "";
		System.out.println("\n\n");
		for (int i=0; i <= plainText.length()-1; i++) {
			spaceCheck = ""+plainText.charAt(i);
			if(spaceCheck.equals(" ")) {
				decodedWord += spaceCheck;
			}
			else {
				int inx = alpha.indexOf(plainText.charAt(i));
				int shiftInx = (inx - key);
				
				
				if (shiftInx < 0) {
					shiftInx = shiftInx + alphaLength;
				}
				decodedWord += alpha.charAt(shiftInx);
				
			//	codedWord += plainText.charAt(i);
			}
		
	}
		return decodedWord;
	}
	public static String[] crack(String codedText) {
		String decodedWord = "";
		String decodedText = "";
	String[] decode = new String[codedText.length()];
		for(int key = 1; key<40; key++ ) {
			decodedWord = "";
			
	for(int i = 0; i<codedText.length(); i++) {
			spaceCheck = ""+codedText.charAt(i);
			if(spaceCheck.equals(" ")) {
				decodedWord += spaceCheck;
			}
			else {
				int inx = alpha.indexOf(codedText.charAt(i));
				int shiftInx = (inx + key);
				
				
				if (shiftInx >= alphaLength) {
					shiftInx = shiftInx - alphaLength;
				}
				
				decodedWord += alpha.charAt(shiftInx);
				
			//	codedWord += plainText.charAt(i);
			}
			

		
			 
		}
	
		}

		
	
		
		return decode;
	
}
}
