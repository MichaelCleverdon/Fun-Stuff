package stopwatch;

import javax.swing.JOptionPane;

public class StartHere {

	public static void main(String[] args) {
	int createOption = 1;
	String watchName;
	
	createOption = JOptionPane.showConfirmDialog(null, "Would you like to create a stopwatch?", "Stopwatch Creation", JOptionPane.YES_NO_OPTION);
	do {
//	System.out.println("Jop returned: " + createOption);
// Yes produces 0, No produces 1

	if(createOption == 0) {
		watchName = JOptionPane.showInputDialog(null, "Enter a name for your stopwatch");
		Stopwatch watch = new Stopwatch(watchName);
		watch.setVisible(true);
		//watch.setLocationByPlatform(true);
	}
	if(createOption == 1) {

	}
	createOption = JOptionPane.showConfirmDialog(null, "Would you like to create ANOTHER stopwatch?", "Stopwatch Creation", JOptionPane.YES_NO_OPTION);
	}while(createOption == 0);
	}

}
