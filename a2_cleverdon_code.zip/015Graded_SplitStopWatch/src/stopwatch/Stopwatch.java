package stopwatch;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Stopwatch extends JFrame {

	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");

	long startTime;
	long stopTime;
	double elapsedTime;
	boolean timeStarted = false;

	String runner1 = JOptionPane.showInputDialog("Enter runner number 1's name: ");
	String runner2 = JOptionPane.showInputDialog("Enter runner number 2's name: ");
	String runner3 = JOptionPane.showInputDialog("Enter runner number 3's name: ");
	String runner4 = JOptionPane.showInputDialog("Enter runner number 4's name: ");
	String runner5 = JOptionPane.showInputDialog("Enter runner number 5's name: ");
	String runner6 = JOptionPane.showInputDialog("Enter runner number 6's name: ");
	String runner7 = JOptionPane.showInputDialog("Enter runner number 7's name: ");

	JButton startButton = new JButton("Start");
	JLabel startLabel = new JLabel();
	JTextField startTextField = new JTextField();

	JButton stopButton = new JButton("Stop");
	JLabel stopLabel = new JLabel();
	JTextField stopTextField = new JTextField();

	JButton stopButton1 = new JButton("Stop");
	JLabel stopLabel1 = new JLabel();
	JTextField stopTextField1 = new JTextField();

	JButton stopButton2 = new JButton("Stop");
	JLabel stopLabel2 = new JLabel();
	JTextField stopTextField2 = new JTextField();

	JButton stopButton3 = new JButton("Stop");
	JLabel stopLabel3 = new JLabel();
	JTextField stopTextField3 = new JTextField();

	JButton stopButton4 = new JButton("Stop");
	JLabel stopLabel4 = new JLabel();
	JTextField stopTextField4 = new JTextField();

	JButton stopButton5 = new JButton("Stop");
	JLabel stopLabel5 = new JLabel();
	JTextField stopTextField5 = new JTextField();

	JButton stopButton6 = new JButton("Stop");
	JLabel stopLabel6 = new JLabel();
	JTextField stopTextField6 = new JTextField();

	JButton closeButton = new JButton("Close");

	JLabel elapsedLabel = new JLabel();
	JTextField elapsedTextField = new JTextField();

	JLabel elapsedLabel1 = new JLabel();
	JTextField elapsedTextField1 = new JTextField();

	JLabel elapsedLabel2 = new JLabel();
	JTextField elapsedTextField2 = new JTextField();

	JLabel elapsedLabel3 = new JLabel();
	JTextField elapsedTextField3 = new JTextField();

	JLabel elapsedLabel4 = new JLabel();
	JTextField elapsedTextField4 = new JTextField();

	JLabel elapsedLabel5 = new JLabel();
	JTextField elapsedTextField5 = new JTextField();

	JLabel elapsedLabel6 = new JLabel();
	JTextField elapsedTextField6 = new JTextField();

	public Stopwatch(String title) {

		setTitle(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Create and Setup content pane
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints gridConstraints = new GridBagConstraints();

		// Create and Setup components
		startButton.setText("Start Timing");

		gridConstraints.gridx = 0;
		gridConstraints.gridy = 0;
		getContentPane().add(startButton, gridConstraints);

		startLabel.setText(" Start System Time ");
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 0;
		getContentPane().add(startLabel, gridConstraints);

		startTextField.setText("");
		startTextField.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 0;
		getContentPane().add(startTextField, gridConstraints);

		// Add Action Listener to detect and respond to clicks
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				startButtonActionPerformed(e);
			}
		});
		
		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButtonActionPerformed(e);
			}
		});
		stopButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton1ActionPerformed(e);
			}
		});
		stopButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton2ActionPerformed(e);
			}
		});
		stopButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton3ActionPerformed(e);
			}
		});
		stopButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton4ActionPerformed(e);
			}
		});
		stopButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton5ActionPerformed(e);
			}
		});
		stopButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stopButton6ActionPerformed(e);
			}
		});
		closeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeButtonActionPerformed(e);
			}
		});

		stopButton.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 1;
		getContentPane().add(stopButton, gridConstraints);

		stopLabel.setText(runner1);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 1;
		getContentPane().add(stopLabel, gridConstraints);

		stopTextField.setText("");
		stopTextField.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 1;
		getContentPane().add(stopTextField, gridConstraints);

		closeButton.setText("Close ALL Watches");
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 20;
		getContentPane().add(closeButton, gridConstraints);

		elapsedLabel.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 1;
		getContentPane().add(elapsedLabel, gridConstraints);

		elapsedTextField.setText("");
		elapsedTextField.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 1;
		getContentPane().add(elapsedTextField, gridConstraints);

		// Runner 2

		stopButton1.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 2;
		getContentPane().add(stopButton1, gridConstraints);

		stopLabel1.setText(runner2);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 2;
		getContentPane().add(stopLabel1, gridConstraints);

		stopTextField1.setText("");
		stopTextField1.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 2;
		getContentPane().add(stopTextField1, gridConstraints);

		elapsedLabel1.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 2;
		getContentPane().add(elapsedLabel1, gridConstraints);

		elapsedTextField1.setText("");
		elapsedTextField1.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 2;
		getContentPane().add(elapsedTextField1, gridConstraints);

		// Runner 3

		stopButton2.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 3;
		getContentPane().add(stopButton2, gridConstraints);

		stopLabel2.setText(runner3);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 3;
		getContentPane().add(stopLabel2, gridConstraints);

		stopTextField2.setText("");
		stopTextField2.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 3;
		getContentPane().add(stopTextField2, gridConstraints);

		elapsedLabel2.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 3;
		getContentPane().add(elapsedLabel2, gridConstraints);

		elapsedTextField2.setText("");
		elapsedTextField2.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 3;
		getContentPane().add(elapsedTextField2, gridConstraints);

		// Runner 4

		stopButton3.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 4;
		getContentPane().add(stopButton3, gridConstraints);

		stopLabel3.setText(runner4);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 4;
		getContentPane().add(stopLabel3, gridConstraints);

		stopTextField3.setText("");
		stopTextField3.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 4;
		getContentPane().add(stopTextField3, gridConstraints);

		elapsedLabel3.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 4;
		getContentPane().add(elapsedLabel3, gridConstraints);

		elapsedTextField3.setText("");
		elapsedTextField3.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 4;
		getContentPane().add(elapsedTextField3, gridConstraints);
		setLocationRelativeTo(null);
		pack();

		// Runner 5
		stopButton4.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 5;
		getContentPane().add(stopButton4, gridConstraints);

		stopLabel4.setText(runner5);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 5;
		getContentPane().add(stopLabel4, gridConstraints);

		stopTextField4.setText("");
		stopTextField4.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 5;
		getContentPane().add(stopTextField4, gridConstraints);

		elapsedLabel4.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 5;
		getContentPane().add(elapsedLabel4, gridConstraints);

		elapsedTextField4.setText("");
		elapsedTextField4.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 5;
		getContentPane().add(elapsedTextField4, gridConstraints);
		setLocationRelativeTo(null);
		pack();

		// Runner 6
		stopButton5.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 6;
		getContentPane().add(stopButton5, gridConstraints);

		stopLabel5.setText(runner6);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 6;
		getContentPane().add(stopLabel5, gridConstraints);

		stopTextField5.setText("");
		stopTextField5.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 6;
		getContentPane().add(stopTextField5, gridConstraints);

		elapsedLabel5.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 6;
		getContentPane().add(elapsedLabel5, gridConstraints);

		elapsedTextField5.setText("");
		elapsedTextField5.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 6;
		getContentPane().add(elapsedTextField5, gridConstraints);
		setLocationRelativeTo(null);
		pack();
		
		
		// Runner 7
		stopButton6.setText("Stop Timing");
		gridConstraints.gridx = 0;
		gridConstraints.gridy = 7;
		getContentPane().add(stopButton6, gridConstraints);

		stopLabel6.setText(runner7);
		gridConstraints.gridx = 1;
		gridConstraints.gridy = 7;
		getContentPane().add(stopLabel6, gridConstraints);

		stopTextField6.setText("");
		stopTextField6.setColumns(20);
		gridConstraints.gridx = 2;
		gridConstraints.gridy = 7;
		getContentPane().add(stopTextField6, gridConstraints);

		elapsedLabel6.setText(" Elapsed Time Seconds ");
		gridConstraints.gridx = 3;
		gridConstraints.gridy = 7;
		getContentPane().add(elapsedLabel6, gridConstraints);

		elapsedTextField6.setText("");
		elapsedTextField6.setColumns(20);
		gridConstraints.gridx = 4;
		gridConstraints.gridy = 7;
		getContentPane().add(elapsedTextField6, gridConstraints);
		setLocationRelativeTo(null);
		pack();
		

	}// End of Constructor
	

	protected void closeButtonActionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.exit(0);
	}
	///////////////////////////////
	// Stop Button Section//
	///////////////////////////////

	protected void stopButtonActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField.setText(stopDate.toString());
			elapsedTextField.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton1ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField1.setText(stopDate.toString());
			elapsedTextField1.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton2ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField2.setText(stopDate.toString());
			elapsedTextField2.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton3ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField3.setText(stopDate.toString());
			elapsedTextField3.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton4ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField4.setText(stopDate.toString());
			elapsedTextField4.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton5ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField5.setText(stopDate.toString());
			elapsedTextField5.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void stopButton6ActionPerformed(ActionEvent e) {
		if (timeStarted = true) {
			stopTime = System.currentTimeMillis();
			Date stopDate = new Date();
			stopTextField6.setText(stopDate.toString());
			elapsedTextField6.setText(String.valueOf((stopTime - startTime) / 1000.0));
			timeStarted = false;
		}
	}

	protected void startButtonActionPerformed(ActionEvent e) {
		startTime = System.currentTimeMillis();
		Date startDate = new Date();
		startTextField.setText(startDate.toString());
		// startTextField.setText(String.valueOf(startTime);
		stopTextField.setText("");
		elapsedTextField.setText("");
		elapsedTextField1.setText("");
		stopTextField1.setText("");
		elapsedTextField2.setText("");
		stopTextField2.setText("");
		elapsedTextField3.setText("");
		stopTextField3.setText("");
		elapsedTextField4.setText("");
		stopTextField4.setText("");
		elapsedTextField5.setText("");
		stopTextField5.setText("");
		elapsedTextField6.setText("");
		stopTextField6.setText("");

		timeStarted = true;
	}// End of Listener
}// End of Class
