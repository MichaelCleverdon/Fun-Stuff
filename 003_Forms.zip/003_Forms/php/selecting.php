

<?php
/* 

$sql = "SELECT id, firstname, lastname, email, reg_date FROM MyGuests";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - 
        Name: " . $row["firstname"]. " 
        " . $row["lastname"]. " 
        Email: " . $row["email"]. "Registration Date: ".
         $row["reg_date"] . "<br>"
         /*."<td>
         <a href='records.php?id="
          . $row["id"] . 
          "'>Edit</a></td>
		<td><a href='delete.php?id=" . $row->id . "'>Delete</a></td>"
		;
    }
} else {
    echo "0 results";
}
*/


?>

Object Oriented
<?php


// Create connection


$sql = "SELECT id, firstname, lastname, email, reg_date, website, comments FROM MyGuests";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th> ID </th><th> First Name </th><th> Last Name </th><th> Email </th><th> Registration Date </th><th>Website</th><th>Comments</th><th></th><th></th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["id"]."</td>";
        echo "<td>".$row["firstname"]."</td>";
        echo "<td>".$row["lastname"]."</td>";
        echo "<td>" . $row["email"]."</td>";
      	echo  "<td>" .$row["reg_date"]."</td>";
		echo "<td>" .$row["website"]."</td>";
		echo "<td>" .$row["comments"]."</td>";
      	echo "<td><a href='php/records.php?id=" . $row["id"] . "'>Edit</a></td>";
		echo "<td><a href='php/delete.php?id=" . $row["id"] . "'>Delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

?>

