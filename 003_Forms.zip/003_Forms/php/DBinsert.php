<?php
//Resets Julie Mary and John




$sql1 = "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('John', 'Doe', 'john@example.com');";
$sql1 .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Mary', 'Moe', 'mary@example.com');";
$sql1 .= "INSERT INTO MyGuests (firstname, lastname, email)
VALUES ('Julie', 'Dooley', 'julie@example.com');";

if ($conn->multi_query($sql1) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql1 . "<br>" . $conn->error;
}

?>