<?php
//Server info
//Dev Version
$servername = "127.0.0.1";
$username = "root";
$password = "toor";
$db = "DBa1";


/* Ops Version
$servername = "DBa1root.db.9259277.47b.hostedresourse.net";
$username = "DBa1root";
$password = "Dba1@toor";
$db = "DBa1root";
  
 */
$br = '<br>';
$conn = new mysqli($servername, $username, $password, $db);
	// Check connection
if ($conn->connect_error) {
    die("Connection failed (4 parm): " . $conn->connect_error);
}
echo $br;
echo "Connected successfully using 4 parm method";
echo $br;
?>