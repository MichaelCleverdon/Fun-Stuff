<?php
echo "Closing connection";
$conn -> close();
?>
