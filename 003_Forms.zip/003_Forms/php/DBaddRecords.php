<?php

include 'DBConnect.php';

echo "<br><hr><br>";

$fname = $_POST["firstname"];
echo "First name is: ".$fname."<br>";

$lname = $_POST["lastname"];
echo "Last name is: ".$lname."<br>";

$email = $_POST["email"];
echo "Email is: ".$email."<br>";

$website = $_POST["whichwebsite"];
echo "Website is: ".$website."<br>";

$comments = $_POST["comments"];
echo "Comments are: ".$comments."<br>";




echo "<br>Connect successfully to the database using 4 parm method<br>";

$sql = "INSERT INTO MyGuests(firstname, lastname, email, website, comments)
VALUES('$fname', '$lname','$email','$website','$comments')";


if ($conn->query($sql) === TRUE) {

    echo "<br>New record created successfully.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
//echo '<meta http-equiv="refresh" content="0; url=../index.php" />';
//echo "<a href='../index.php'>Return Home</a>";
$conn -> close();
?>