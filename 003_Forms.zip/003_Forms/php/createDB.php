<?php
//Creating Databases


//Drops database if it exists
$sql = "CREATE DATABASE IF NOT EXISTS DBa1";
if ($conn->query($sql) === TRUE) {
    echo "Database DBa1 created successfully";
} else {
    echo "Error created database: " . $conn->error . $br;
}


?>