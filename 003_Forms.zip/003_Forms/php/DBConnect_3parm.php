<?php
$servername = "127.0.0.1";
$username = "root";
$password = "toor";

$br = '<br>';
$conn = new mysqli($servername, $username, $password);
	// Check connection
if ($conn->connect_error) {
    die("Connection failed (4 parm): " . $conn->connect_error);
}
echo $br;
echo "Connected successfully using 3 parm method";
echo $br;
?>