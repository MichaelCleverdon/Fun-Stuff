<!DOCTYPE html>
<html>
	<head>
		<title>PHP Forms</title>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
		<link href="https://fonts.googleapis.com/css?family=Merriweather|Montserrat|Oswald|Roboto|Londrina+Solid|Spectral+SC" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/css.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script src="js/slideToggle.js"></script>
		<script src="js/external.js"></script>
		
		
	</head>
	<body>
		<div class="w3-sidebar w3-bar-block w3-border-right" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-large w3-yellow">Close &times;</button>
 <a href="#" class="w3-hover-blue-gray w3-bar-item w3-button">.Tech Links</a>
  <!--Row 1-->
  <a href="www.westada.tech/a1/gavinb/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Gavin B</a>
  <a href="www.westada.tech/a1/jpm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mu</a>
  <a href="www.westada.tech/a1/zacharys/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Zachary S</a>
  
  <a href="www.westada.tech/a1/bryanh/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Bryan H</a>
  <a href="www.westada.tech/a1/josephm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mo</a>
  <a href="www.westada.tech/a1/kenisons/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Kenison S</a>
 
  <!--Row 2-->
  <a href="www.westada.tech/a1/chases/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Chase S</a>
  <a href="www.westada.tech/a1/davidb/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">David B</a>
  <a href="www.westada.tech/a1/connorc/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Connor C</a> 
  <a href="www.westada.tech/a1//peterc" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Peter C</a>
  <a href="www.westada.tech/a1//andrewh" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Andrew H</a>
  
  <!--Row 3-->
  <a href="www.westada.tech/a1/jamesr/" class="w3-hover-blue-gray w3-pale-green  w3-bar-item w3-button">James R</a>
  <a href="www.westada.tech/a1/alysec/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Alyse C</a>
  <a href="www.westada.tech/a1/hunterf/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Hunter F</a>
  <a href="www.westada.tech/a1/michaelc/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Michael C</a>
  
  <a href="www.westada.tech/a1/heathers/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Heather S</a>
  <a href="www.westada.tech/a1/briellel/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Brielle L</a>
  <a href="www.westada.tech/a1/tannerh/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Tanner H</a>
  <a href="www.westada.tech/a1/richardm/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Richard M</a>
  
   <a href="#" class="w3-hover-blue-gray w3-bar-item w3-button">.Net Links</a>
  <!--Row 1-->
  <a href="http://www.westada.net/a1/gavinb/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Gavin B</a>
  <a href="http://www.westada.net/a1/jpm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mu</a>
  <a href="http://www.westada.net/a1/zacharys/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Zachary S</a>
  
  <a href="http://www.westada.net/a1/bryanh/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Bryan H</a>
  <a href="http://www.westada.net/a1/josephm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mo</a>
  <a href="http://www.westada.net/a1/kenisons/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Kenison S</a>
 
  <!--Row 2-->
  <a href="http://www.westada.net/a1/chases/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Chase S</a>
  <a href="http://www.westada.net/a1/davidb/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">David B</a>
  <a href="http://www.westada.net/a1/connorc/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Connor C</a> 
  <a href="http://www.westada.net/a1//peterc" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Peter C</a>
  <a href="http://www.westada.net/a1//andrewh" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Andrew H</a>
  
  <!--Row 3-->
  <a href="http://www.westada.net/a1/jamesr/" class="w3-hover-blue-gray w3-pale-green  w3-bar-item w3-button">James R</a>
  <a href="http://www.westada.net/a1/alysec/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Alyse C</a>
  <a href="http://www.westada.net/a1/hunterf/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Hunter F</a>
  <a href="http://www.westada.net/a1/michaelc/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Michael C</a>
  
  <a href="http://www.westada.net/a1/heathers/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Heather S</a>
  <a href="http://www.westada.net/a1/briellel/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Brielle L</a>
  <a href="http://www.westada.net/a1/tannerh/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Tanner H</a>
  <a href="http://www.westada.net/a1/richardm/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Richard M</a>
  
  
  
  <a href="#" class="w3-hover-blue-gray w3-bar-item w3-button">Developer Links</a>
  <!--Row 1-->
  <a href="http://192.168.1.102/a1gavinb/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Gavin B</a>
  <a href="http://192.168.1.103/a1jpm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mu</a>
  <a href="http://192.168.1.104/a1zacharys/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Zachary S</a>
  
  <a href="http://192.168.1.105/a1bryanh/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Bryan H</a>
  <a href="http://192.168.1.106/a1josephm/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Joseph Mo</a>
  <a href="http://192.168.1.107/a1kenisons/" class="w3-hover-blue-gray w3-pale-blue w3-bar-item w3-button">Kenison S</a>
 
  <!--Row 2-->
  <a href="http://192.168.1.109/a1chases/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Chase S</a>
  <a href="http://192.168.1.110/a1davidb/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">David B</a>
  <a href="http://192.168.1.111/a1connorc/" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Connor C</a>
   
  <a href="http://192.168.1.114/a1/peterc" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Peter C</a>
  <a href="http://192.168.1.115/a1/andrewh" class="w3-hover-blue-gray w3-pale-red w3-bar-item w3-button">Andrew H</a>
  
  <!--Row 3-->
  <a href="http://192.168.1.117/a1jamesr/" class="w3-hover-blue-gray w3-pale-green  w3-bar-item w3-button">James R</a>
  <a href="http://192.168.1.118/a1alysec/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Alyse C</a>
  <a href="http://192.168.1.119/a1hunterf/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Hunter F</a>
  <a href="http://192.168.1.120/a1michaelc/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Michael C</a>
  
  <a href="http://192.168.1.121/a1heathers/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Heather S</a>
  <a href="http://192.168.1.122/a1briellel/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Brielle L</a>
  <a href="http://192.168.1.123/a1tannerh/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Tanner H</a>
  <a href="http://192.168.1.124/a1richardm/" class="w3-hover-blue-gray w3-pale-green w3-bar-item w3-button">Richard M</a>
  
  
 
</div>

<!-- Page Content -->
<div style="text-align: left" class="w3-pale-yellow">
  <button class="w3-button w3-pale-yellow w3-xlarge" onclick="w3_open()">☰</button>
  <div class="w3-amber w3-container">

 
		<h1>First time using PHP and SQL to process forms!</h1>
		<h2>Created by Michael C on November 16, 2017</h2>
		<h3>Last Updated Jan 12, 2017</h3>
		 </div>
</div>
		<hr>
		<br>
		<hr>
		<h4>Now it's time to start some PHP!</h4>
		<?php
		//Dev only, need to deactivate for Ops
		
		//This is to create the Database
	include 'php/DBConnect_3parm.php';
	include 'php/createDB.php';
	include 'php/DBClose.php';
	//This is to make the table if it doesn't exist
	include 'php/DBConnect.php';
	include 'php/makeTable.php';

	include 'php/DBClose.php';

	//End of Dev only
	?>
	<hr>
	<br>
	<hr>
	<h4>Form time!</h4>
	<br>
	
	<form id="NameEmailForm" action="php/DBaddRecords.php" method="post">
		First name: <br>
		<input type="text" name="firstname"><br>
		Last name: <br>
		<input type="text" name="lastname"><br>
		Email: <br>
		<input type="text" name="email"><br>
		Which Website are you commenting on? (format like the end of the URL: michaelc): 
		<br>
		<input type="text" name="whichwebsite">
		<br>
		
		Comments: 
		<br>
		<textarea name="comments" rows="3" columns="10"></textarea>
		<br>
		<input type="submit">
		<input type="button" onclick="clearForm()" value="Clear form">
	</form>
	<!--Start of Div stack-->
	<h1 id="showErd">Click here to show the ERD in Normal Form!</h1>
	<div id="erd">
		<p>Here are some examples of some ERD's I've made this year</p>
		<img src="images/erd1.png" alt="erd1">
		<p></p>
		<img src="images/erd2.png" height="600" width="auto">
		<p>This is the pizza company's database in UNF</p>
		<img src="images/1nf.png">
		<p>After that, I had to make it into first normal form.</p>
		<img src="images/2nf.png">
		<p>First normal form is when the table has no repeating groups and every group is seperated into unique groups</p>

	</div>
	<h1 id="showPhp">Click here to show the PHP!</h1>
	<div id="php">
		<p>Here's some of my PHP code that I've made this year</p>
		<img src="images/php1.png" alt="php1" height="300" width="auto"float="left">
		<img src="images/php2.png" alt="php2" float="middle">
		<img src="images/php3.png" alt="php3" float="right">
		

	</div>
	<h1 id="showSql">Click here to show the SQL!</h1>
	<div id="sql">
		<p>These are examples of the SQL I've done in my database class</p>
		<img src="images/sql1.png" alt="sql1" float="left">
		<img src="images/sql2.png" alt="sql2" float="right">
	</div>
	<hr>
	<h3>Retrieve Data from our Database</h3>
		<?php
		include 'php/DBConnect.php';
		include 'php/selecting.php';
		include 'php/DBClose.php';
		?>
		<hr>
		
		
	<hr>
	
	
	</body>
	
</html>